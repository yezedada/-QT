﻿#pragma once
#include <iostream>
#include <string>
using namespace std;

class Worker
{
public:
	string m_ID; //职工编号
	string m_Name;	//职工姓名
	string m_DeptId; //部门id
	string m_Gender; //性别
	int	   m_Wage; //工资
	string m_Marital; //婚否
	short year;
	short month;
	short day;

	virtual void ShowInfomation() = 0; //显示信息
	virtual string getDeptName() = 0; //获得岗位名称
};

