﻿#include "MainInterface.h"
#include "qdebug.h"
#include "Boss.h"
#include "Employee.h"
#include "Manager.h"
#include <qmessagebox.h>


MainInterface::MainInterface(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainInterfaceClass())
{
    ui->setupUi(this);
    this->resize(800, 600);
    this->setWindowTitle("员工管理系统");
    //员工显示窗口
    viewWindow = new ViewingEmployeeWindow;
    //员工添加窗口
    addWindow = new AddAndModifyEmployeesWindow;

    //读取文件数据
    this->ReadFileDate();

    //监听显示窗口
    connect(ui->actionViewingEmployee, &QAction::triggered, this, [=]()
        {

            //viewWindow->setAttribute(Qt::WA_DeleteOnClose);

            viewWindow->TableInit(m_EmployeeNum, worker);
            viewWindow->show();
        });
    //监听添加窗口
    connect(ui->actionAddEmployees, &QAction::triggered, this, [=]()
        {
            //addWindow->setAttribute(Qt::WA_DeleteOnClose);
            addWindow->show();
        });

    //监听添加数据信号
    connect(this->addWindow, &AddAndModifyEmployeesWindow::signalsAddInformation, this, &MainInterface::AddInformation);
    //监听修改数据信号
    connect(this->viewWindow->modWindow, &AddAndModifyEmployeesWindow::signalsModInformation, this, &MainInterface::ModifyInformation);
    //监听删除数据信号
    connect(this->viewWindow, &ViewingEmployeeWindow::signalsDeleteInformation, this, &MainInterface::DeleteInformation);

}
//文件数据个数判断
int MainInterface::FileDataNum()
{
    QFile file(FILEPATH);
    QByteArray data;
    int number = 0;
    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while (!file.atEnd())
        {
            data = file.readLine();
            number++;
        }
    } 
    file.close();
    return number;
}
//在文件中读取数据
void MainInterface::ReadFileDate()
{
    QFile file(FILEPATH);
    QByteArray data;
    QString temp, id, name, deptId, gender, wage, marital, year, month, day;
    Worker** tempWorker = NULL;
    Worker* tempData = NULL;
    int tempWorkerNum = 0;
    int tempWorkerNumIndex = 0;

    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        data = file.readLine();
        if (data[0] == '\0')
        {
            qDebug() << "文件为空";
            return;
        }
        else
        {
            qDebug() << "文件不为空";

            //判断文件中有多少行数据
            tempWorkerNum = this->FileDataNum();
            //存放文件数据的空间
            tempWorker = new Worker * [tempWorkerNum + sizeof(Worker)];
            while(tempWorkerNumIndex != tempWorkerNum)
            {
                temp = data;
                id = temp.section("/", 0, 0).trimmed();
                name = temp.section("/", 1, 1).trimmed();
                deptId = temp.section("/", 2, 2).trimmed();
                gender = temp.section("/", 3, 3).trimmed();
                marital = temp.section("/", 4, 4).trimmed();
                wage = temp.section("/", 5, 5).trimmed();
                year = temp.section("/", 6, 6).trimmed();
                month = temp.section("/", 7, 7).trimmed();
                day = temp.section("/", 8, 8).trimmed();

                if (deptId == "普通职工")
                {
                    tempData = new Employee(id.toStdString(), name.toStdString(), deptId.toStdString()
                        , gender.toStdString(), wage.toInt(), marital.toStdString(), year.toShort(), month.toShort(), day.toShort());
                }
                else if (deptId == "经理")
                {
                    tempData = new Manager(id.toStdString(), name.toStdString(), deptId.toStdString()
                        , gender.toStdString(), wage.toInt(), marital.toStdString(), year.toShort(),month.toShort(),day.toShort());
                }
                else if (deptId == "老板")
                {
                    tempData = new Boss(id.toStdString(), name.toStdString(), deptId.toStdString()
                        , gender.toStdString(), wage.toInt(), marital.toStdString(), year.toShort(), month.toShort(), day.toShort());
                }
                tempWorker[tempWorkerNumIndex] = tempData;
                data = file.readLine();
                tempWorkerNumIndex++;
            }

            //更新内存中的数据
            this->worker = tempWorker;
            //更新内存中的数据个数
            this->m_EmployeeNum = tempWorkerNum;
            this->addWindow->setEmployeeInfomation(this->worker);
            this->addWindow->setEmployeeNumber(this->m_EmployeeNum);
            file.close();
        }
    }
    else
    {
        qDebug() << "文件打开失败";
    }  
}
//把数据写入文件
void MainInterface::WriteFileDate()
{
    QFile file(FILEPATH);
    QByteArray data;
    QString temp;
    if (file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        for (int i = 0; i < this->m_EmployeeNum; i++)
        {
            temp = QString::fromStdString(this->worker[i]->m_ID) + "/"
                + QString::fromStdString(this->worker[i]->m_Name) + "/"
                + QString::fromStdString(this->worker[i]->m_DeptId) + "/" 
                + QString::fromStdString(this->worker[i]->m_Gender) + "/"
                + QString::fromStdString(this->worker[i]->m_Marital) + "/"
                + QString::number(this->worker[i]->m_Wage) + "/"
                + QString::number(this->worker[i]->year) + "/"
                + QString::number(this->worker[i]->month) + "/"
                + QString::number(this->worker[i]->day) + "/"
                + "\n";
            data = temp.toUtf8();
            file.write(data);
        }
        file.close();
    }
    else
    {
        qDebug() << "文件打开失败";
    }
}

//添加员工信息
void MainInterface::AddInformation()
{
    //总人数 = 当前人数 + 新添加的人数
    this->m_EmployeeNum = addWindow->getEmployeeNumber();
    qDebug() << "当前记录的总人数:" << this->m_EmployeeNum;
    this->worker = addWindow->getEmployeeInfomation();
}
//修改员工信息
void MainInterface::ModifyInformation()
{
    this->modWorker = viewWindow->modWindow->getModifyEmployeeInfomation();
    this->modWorkerIndex = viewWindow->modWindow->getModifyEmployeeIndex();

    qDebug() << "选中的是第几行数据：" << this->modWorkerIndex + 1;
    qDebug() << QString::fromStdString(this->modWorker->m_DeptId);

    worker[this->modWorkerIndex] = this->modWorker;
    //更新到表格
    viewWindow->TableInit(m_EmployeeNum, worker);
}
//删除员工信息
void  MainInterface::DeleteInformation()
{
    this->modWorkerIndex = viewWindow->getDeleteEmployeeIndex();
    
    Worker* temp = worker[this->modWorkerIndex];
    for (int i = this->modWorkerIndex; i < this->m_EmployeeNum - 1; i++)
    {
        worker[i] = worker[i + 1];
    }
    delete temp;
    this->m_EmployeeNum--;
    this->addWindow->setEmployeeNumber(this->m_EmployeeNum);
    this->addWindow->setEmployeeInfomation(this->worker);
}

//显示员工信息
void MainInterface::ShowEmployees()
{

}

MainInterface::~MainInterface()
{
    delete ui;
    if (this->worker != NULL)
    {
        for (int i = 0; i < this->m_EmployeeNum; i++)
        {
            if (this->worker[i] != NULL)
            {
                delete this->worker[i];
            }
        }
        delete[] this->worker;
        this->worker = NULL;
    }
}

//重写退出事件
void MainInterface::closeEvent(QCloseEvent* event)
{
    int choose;
    choose = QMessageBox::question(this, tr("退出程序"),
        QString(tr("确认退出程序?")),
        QMessageBox::Yes | QMessageBox::No);

    if (choose == QMessageBox::No)
    {
        event->ignore();  //忽略//程序继续运行
    }
    else if (choose == QMessageBox::Yes)
    {
        //退出程序时保存文件
        this->WriteFileDate();
        event->accept();  //介绍//程序退出
    }
}
