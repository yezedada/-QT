/********************************************************************************
** Form generated from reading UI file 'AddAndModifyEmployeesWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDANDMODIFYEMPLOYEESWINDOW_H
#define UI_ADDANDMODIFYEMPLOYEESWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddAndModifyEmployeesWindowClass
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QWidget *widget_5;
    QVBoxLayout *verticalLayout;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QLabel *label;
    QLineEdit *GetEmployeesNumber;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_2;
    QLineEdit *GetEmployeesName;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *verticalSpacer;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_7;
    QLabel *label_3;
    QComboBox *GetEmployeesPosition;
    QSpacerItem *horizontalSpacer_8;
    QSpacerItem *verticalSpacer_2;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *AddAndModBtn;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *ResetBtn;
    QSpacerItem *horizontalSpacer_6;

    void setupUi(QWidget *AddAndModifyEmployeesWindowClass)
    {
        if (AddAndModifyEmployeesWindowClass->objectName().isEmpty())
            AddAndModifyEmployeesWindowClass->setObjectName(QString::fromUtf8("AddAndModifyEmployeesWindowClass"));
        AddAndModifyEmployeesWindowClass->resize(601, 418);
        widget = new QWidget(AddAndModifyEmployeesWindowClass);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(30, 10, 551, 351));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        widget_5 = new QWidget(widget);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        verticalLayout = new QVBoxLayout(widget_5);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget_2 = new QWidget(widget_5);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout = new QHBoxLayout(widget_2);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        GetEmployeesNumber = new QLineEdit(widget_2);
        GetEmployeesNumber->setObjectName(QString::fromUtf8("GetEmployeesNumber"));

        horizontalLayout->addWidget(GetEmployeesNumber);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        GetEmployeesName = new QLineEdit(widget_2);
        GetEmployeesName->setObjectName(QString::fromUtf8("GetEmployeesName"));

        horizontalLayout->addWidget(GetEmployeesName);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);


        verticalLayout->addWidget(widget_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        widget_3 = new QWidget(widget_5);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout_2 = new QHBoxLayout(widget_3);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_7);

        label_3 = new QLabel(widget_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        GetEmployeesPosition = new QComboBox(widget_3);
        GetEmployeesPosition->addItem(QString());
        GetEmployeesPosition->addItem(QString());
        GetEmployeesPosition->addItem(QString());
        GetEmployeesPosition->setObjectName(QString::fromUtf8("GetEmployeesPosition"));

        horizontalLayout_2->addWidget(GetEmployeesPosition);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_8);


        verticalLayout->addWidget(widget_3);


        verticalLayout_2->addWidget(widget_5);

        verticalSpacer_2 = new QSpacerItem(20, 146, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);

        widget_4 = new QWidget(widget);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_3 = new QHBoxLayout(widget_4);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);

        AddAndModBtn = new QPushButton(widget_4);
        AddAndModBtn->setObjectName(QString::fromUtf8("AddAndModBtn"));

        horizontalLayout_3->addWidget(AddAndModBtn);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);

        ResetBtn = new QPushButton(widget_4);
        ResetBtn->setObjectName(QString::fromUtf8("ResetBtn"));

        horizontalLayout_3->addWidget(ResetBtn);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_6);


        verticalLayout_2->addWidget(widget_4);


        retranslateUi(AddAndModifyEmployeesWindowClass);

        QMetaObject::connectSlotsByName(AddAndModifyEmployeesWindowClass);
    } // setupUi

    void retranslateUi(QWidget *AddAndModifyEmployeesWindowClass)
    {
        AddAndModifyEmployeesWindowClass->setWindowTitle(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "AddAndModifyEmployeesWindow", nullptr));
        label->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\350\201\214\345\267\245\347\274\226\345\217\267\357\274\232", nullptr));
        label_2->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\350\201\214\345\267\245\345\247\223\345\220\215\357\274\232", nullptr));
        label_3->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\345\267\245\344\275\234\350\201\214\344\275\215\357\274\232", nullptr));
        GetEmployeesPosition->setItemText(0, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\346\231\256\351\200\232\350\201\214\345\267\245", nullptr));
        GetEmployeesPosition->setItemText(1, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\347\273\217\347\220\206", nullptr));
        GetEmployeesPosition->setItemText(2, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\350\200\201\346\235\277", nullptr));

        AddAndModBtn->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\346\267\273\345\212\240", nullptr));
        ResetBtn->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\351\207\215\347\275\256", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddAndModifyEmployeesWindowClass: public Ui_AddAndModifyEmployeesWindowClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDANDMODIFYEMPLOYEESWINDOW_H
