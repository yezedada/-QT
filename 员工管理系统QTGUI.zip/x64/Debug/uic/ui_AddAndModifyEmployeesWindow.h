/********************************************************************************
** Form generated from reading UI file 'AddAndModifyEmployeesWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDANDMODIFYEMPLOYEESWINDOW_H
#define UI_ADDANDMODIFYEMPLOYEESWINDOW_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddAndModifyEmployeesWindowClass
{
public:
    QHBoxLayout *horizontalLayout_5;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QWidget *widget_5;
    QGridLayout *gridLayout;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QLabel *label;
    QLineEdit *GetEmployeesNumber;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_2;
    QLineEdit *GetEmployeesName;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *verticalSpacer;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_9;
    QLabel *label_4;
    QComboBox *GetEmployeesGender;
    QSpacerItem *horizontalSpacer_7;
    QLabel *label_3;
    QComboBox *GetEmployeesPosition;
    QSpacerItem *horizontalSpacer_8;
    QSpacerItem *verticalSpacer_3;
    QWidget *widget_6;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_10;
    QLabel *label_5;
    QLineEdit *GetEmployeesWage;
    QLabel *label_6;
    QSpacerItem *horizontalSpacer_11;
    QLabel *label_7;
    QComboBox *GetEmployeesMarital;
    QSpacerItem *horizontalSpacer_12;
    QSpacerItem *verticalSpacer_2;
    QWidget *widget_7;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer_13;
    QLabel *label_8;
    QDateEdit *GetDate;
    QSpacerItem *horizontalSpacer_14;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *AddAndModBtn;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *ResetBtn;
    QSpacerItem *horizontalSpacer_6;

    void setupUi(QWidget *AddAndModifyEmployeesWindowClass)
    {
        if (AddAndModifyEmployeesWindowClass->objectName().isEmpty())
            AddAndModifyEmployeesWindowClass->setObjectName(QString::fromUtf8("AddAndModifyEmployeesWindowClass"));
        AddAndModifyEmployeesWindowClass->resize(601, 418);
        horizontalLayout_5 = new QHBoxLayout(AddAndModifyEmployeesWindowClass);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        widget = new QWidget(AddAndModifyEmployeesWindowClass);
        widget->setObjectName(QString::fromUtf8("widget"));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        widget_5 = new QWidget(widget);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        gridLayout = new QGridLayout(widget_5);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        widget_2 = new QWidget(widget_5);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout = new QHBoxLayout(widget_2);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        GetEmployeesNumber = new QLineEdit(widget_2);
        GetEmployeesNumber->setObjectName(QString::fromUtf8("GetEmployeesNumber"));

        horizontalLayout->addWidget(GetEmployeesNumber);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        GetEmployeesName = new QLineEdit(widget_2);
        GetEmployeesName->setObjectName(QString::fromUtf8("GetEmployeesName"));

        horizontalLayout->addWidget(GetEmployeesName);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);


        gridLayout->addWidget(widget_2, 0, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 1, 0, 1, 1);

        widget_3 = new QWidget(widget_5);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout_2 = new QHBoxLayout(widget_3);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_9);

        label_4 = new QLabel(widget_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_2->addWidget(label_4);

        GetEmployeesGender = new QComboBox(widget_3);
        GetEmployeesGender->addItem(QString());
        GetEmployeesGender->addItem(QString());
        GetEmployeesGender->setObjectName(QString::fromUtf8("GetEmployeesGender"));

        horizontalLayout_2->addWidget(GetEmployeesGender);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_7);

        label_3 = new QLabel(widget_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        GetEmployeesPosition = new QComboBox(widget_3);
        GetEmployeesPosition->addItem(QString());
        GetEmployeesPosition->addItem(QString());
        GetEmployeesPosition->addItem(QString());
        GetEmployeesPosition->setObjectName(QString::fromUtf8("GetEmployeesPosition"));

        horizontalLayout_2->addWidget(GetEmployeesPosition);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_8);


        gridLayout->addWidget(widget_3, 2, 0, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_3, 3, 0, 1, 1);

        widget_6 = new QWidget(widget_5);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        horizontalLayout_4 = new QHBoxLayout(widget_6);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_10);

        label_5 = new QLabel(widget_6);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_4->addWidget(label_5);

        GetEmployeesWage = new QLineEdit(widget_6);
        GetEmployeesWage->setObjectName(QString::fromUtf8("GetEmployeesWage"));
        GetEmployeesWage->setMaximumSize(QSize(60, 16777215));

        horizontalLayout_4->addWidget(GetEmployeesWage);

        label_6 = new QLabel(widget_6);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_4->addWidget(label_6);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_11);

        label_7 = new QLabel(widget_6);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_4->addWidget(label_7);

        GetEmployeesMarital = new QComboBox(widget_6);
        GetEmployeesMarital->addItem(QString());
        GetEmployeesMarital->addItem(QString());
        GetEmployeesMarital->addItem(QString());
        GetEmployeesMarital->addItem(QString());
        GetEmployeesMarital->setObjectName(QString::fromUtf8("GetEmployeesMarital"));

        horizontalLayout_4->addWidget(GetEmployeesMarital);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_12);


        gridLayout->addWidget(widget_6, 4, 0, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 5, 0, 1, 1);

        widget_7 = new QWidget(widget_5);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        horizontalLayout_6 = new QHBoxLayout(widget_7);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_13);

        label_8 = new QLabel(widget_7);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_6->addWidget(label_8);

        GetDate = new QDateEdit(widget_7);
        GetDate->setObjectName(QString::fromUtf8("GetDate"));
        GetDate->setMaximumDate(QDate(2100, 12, 31));

        horizontalLayout_6->addWidget(GetDate);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_14);


        gridLayout->addWidget(widget_7, 6, 0, 1, 1);


        verticalLayout_2->addWidget(widget_5);

        widget_4 = new QWidget(widget);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_3 = new QHBoxLayout(widget_4);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);

        AddAndModBtn = new QPushButton(widget_4);
        AddAndModBtn->setObjectName(QString::fromUtf8("AddAndModBtn"));

        horizontalLayout_3->addWidget(AddAndModBtn);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);

        ResetBtn = new QPushButton(widget_4);
        ResetBtn->setObjectName(QString::fromUtf8("ResetBtn"));

        horizontalLayout_3->addWidget(ResetBtn);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_6);


        verticalLayout_2->addWidget(widget_4);


        horizontalLayout_5->addWidget(widget);


        retranslateUi(AddAndModifyEmployeesWindowClass);

        QMetaObject::connectSlotsByName(AddAndModifyEmployeesWindowClass);
    } // setupUi

    void retranslateUi(QWidget *AddAndModifyEmployeesWindowClass)
    {
        AddAndModifyEmployeesWindowClass->setWindowTitle(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "AddAndModifyEmployeesWindow", nullptr));
        label->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\350\201\214\345\267\245\347\274\226\345\217\267\357\274\232", nullptr));
        label_2->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\350\201\214\345\267\245\345\247\223\345\220\215\357\274\232", nullptr));
        label_4->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\350\201\214\345\267\245\346\200\247\345\210\253\357\274\232", nullptr));
        GetEmployeesGender->setItemText(0, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\347\224\267", nullptr));
        GetEmployeesGender->setItemText(1, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\345\245\263", nullptr));

        label_3->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\345\267\245\344\275\234\350\201\214\344\275\215\357\274\232", nullptr));
        GetEmployeesPosition->setItemText(0, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\346\231\256\351\200\232\350\201\214\345\267\245", nullptr));
        GetEmployeesPosition->setItemText(1, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\347\273\217\347\220\206", nullptr));
        GetEmployeesPosition->setItemText(2, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\350\200\201\346\235\277", nullptr));

        label_5->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\350\201\214\345\267\245\345\267\245\350\265\204\357\274\232", nullptr));
        label_6->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\345\205\203", nullptr));
        label_7->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\345\251\232\345\220\246\357\274\232", nullptr));
        GetEmployeesMarital->setItemText(0, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\346\234\252\345\251\232", nullptr));
        GetEmployeesMarital->setItemText(1, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\345\267\262\345\251\232", nullptr));
        GetEmployeesMarital->setItemText(2, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\347\246\273\345\274\202", nullptr));
        GetEmployeesMarital->setItemText(3, QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\344\270\247\345\201\266", nullptr));

        label_8->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\345\207\272\347\224\237\346\227\245\346\234\237\357\274\232", nullptr));
        AddAndModBtn->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\346\267\273\345\212\240", nullptr));
        ResetBtn->setText(QCoreApplication::translate("AddAndModifyEmployeesWindowClass", "\351\207\215\347\275\256", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddAndModifyEmployeesWindowClass: public Ui_AddAndModifyEmployeesWindowClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDANDMODIFYEMPLOYEESWINDOW_H
