/********************************************************************************
** Form generated from reading UI file 'ViewingEmployeeWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIEWINGEMPLOYEEWINDOW_H
#define UI_VIEWINGEMPLOYEEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ViewingEmployeeWindowClass
{
public:
    QHBoxLayout *horizontalLayout_4;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout;
    QLabel *EmpNumber;
    QLineEdit *GetEmpNumber;
    QSpacerItem *horizontalSpacer_2;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *EmpName;
    QLineEdit *GetEmpName;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *SearchBtn;
    QTableWidget *tableWidget;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *ModifyBtn;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *DeleteBtn;
    QSpacerItem *horizontalSpacer_5;

    void setupUi(QWidget *ViewingEmployeeWindowClass)
    {
        if (ViewingEmployeeWindowClass->objectName().isEmpty())
            ViewingEmployeeWindowClass->setObjectName(QString::fromUtf8("ViewingEmployeeWindowClass"));
        ViewingEmployeeWindowClass->resize(757, 552);
        horizontalLayout_4 = new QHBoxLayout(ViewingEmployeeWindowClass);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        widget = new QWidget(ViewingEmployeeWindowClass);
        widget->setObjectName(QString::fromUtf8("widget"));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        groupBox = new QGroupBox(widget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        horizontalLayout_3 = new QHBoxLayout(groupBox);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        widget_2 = new QWidget(groupBox);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout = new QHBoxLayout(widget_2);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        EmpNumber = new QLabel(widget_2);
        EmpNumber->setObjectName(QString::fromUtf8("EmpNumber"));

        horizontalLayout->addWidget(EmpNumber);

        GetEmpNumber = new QLineEdit(widget_2);
        GetEmpNumber->setObjectName(QString::fromUtf8("GetEmpNumber"));

        horizontalLayout->addWidget(GetEmpNumber);


        horizontalLayout_3->addWidget(widget_2);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);

        widget_3 = new QWidget(groupBox);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout_2 = new QHBoxLayout(widget_3);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        EmpName = new QLabel(widget_3);
        EmpName->setObjectName(QString::fromUtf8("EmpName"));

        horizontalLayout_2->addWidget(EmpName);

        GetEmpName = new QLineEdit(widget_3);
        GetEmpName->setObjectName(QString::fromUtf8("GetEmpName"));

        horizontalLayout_2->addWidget(GetEmpName);


        horizontalLayout_3->addWidget(widget_3);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        SearchBtn = new QPushButton(groupBox);
        SearchBtn->setObjectName(QString::fromUtf8("SearchBtn"));

        horizontalLayout_3->addWidget(SearchBtn);


        verticalLayout->addWidget(groupBox);

        tableWidget = new QTableWidget(widget);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));

        verticalLayout->addWidget(tableWidget);

        widget_4 = new QWidget(widget);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_5 = new QHBoxLayout(widget_4);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_4);

        ModifyBtn = new QPushButton(widget_4);
        ModifyBtn->setObjectName(QString::fromUtf8("ModifyBtn"));

        horizontalLayout_5->addWidget(ModifyBtn);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_6);

        DeleteBtn = new QPushButton(widget_4);
        DeleteBtn->setObjectName(QString::fromUtf8("DeleteBtn"));

        horizontalLayout_5->addWidget(DeleteBtn);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_5);


        verticalLayout->addWidget(widget_4);


        horizontalLayout_4->addWidget(widget);


        retranslateUi(ViewingEmployeeWindowClass);

        QMetaObject::connectSlotsByName(ViewingEmployeeWindowClass);
    } // setupUi

    void retranslateUi(QWidget *ViewingEmployeeWindowClass)
    {
        ViewingEmployeeWindowClass->setWindowTitle(QCoreApplication::translate("ViewingEmployeeWindowClass", "ViewingEmployeeWindow", nullptr));
        groupBox->setTitle(QCoreApplication::translate("ViewingEmployeeWindowClass", "\346\220\234\347\264\242\346\235\241\344\273\266", nullptr));
        EmpNumber->setText(QCoreApplication::translate("ViewingEmployeeWindowClass", "\345\221\230\345\267\245\345\267\245\345\217\267:", nullptr));
        EmpName->setText(QCoreApplication::translate("ViewingEmployeeWindowClass", "\345\221\230\345\267\245\345\247\223\345\220\215:", nullptr));
        SearchBtn->setText(QCoreApplication::translate("ViewingEmployeeWindowClass", "\346\220\234\347\264\242", nullptr));
        ModifyBtn->setText(QCoreApplication::translate("ViewingEmployeeWindowClass", "\344\277\256\346\224\271", nullptr));
        DeleteBtn->setText(QCoreApplication::translate("ViewingEmployeeWindowClass", "\345\210\240\351\231\244", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ViewingEmployeeWindowClass: public Ui_ViewingEmployeeWindowClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIEWINGEMPLOYEEWINDOW_H
