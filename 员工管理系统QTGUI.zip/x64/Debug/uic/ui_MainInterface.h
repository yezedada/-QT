/********************************************************************************
** Form generated from reading UI file 'MainInterface.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAININTERFACE_H
#define UI_MAININTERFACE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainInterfaceClass
{
public:
    QAction *actionAddEmployees;
    QAction *actionViewingEmployee;
    QWidget *centralWidget;
    QMenuBar *menuBar;
    QMenu *menuemployees;
    QToolBar *mainToolBar;

    void setupUi(QMainWindow *MainInterfaceClass)
    {
        if (MainInterfaceClass->objectName().isEmpty())
            MainInterfaceClass->setObjectName(QString::fromUtf8("MainInterfaceClass"));
        MainInterfaceClass->resize(600, 400);
        actionAddEmployees = new QAction(MainInterfaceClass);
        actionAddEmployees->setObjectName(QString::fromUtf8("actionAddEmployees"));
        actionAddEmployees->setEnabled(true);
        actionViewingEmployee = new QAction(MainInterfaceClass);
        actionViewingEmployee->setObjectName(QString::fromUtf8("actionViewingEmployee"));
        centralWidget = new QWidget(MainInterfaceClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        MainInterfaceClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainInterfaceClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 600, 17));
        menuemployees = new QMenu(menuBar);
        menuemployees->setObjectName(QString::fromUtf8("menuemployees"));
        MainInterfaceClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainInterfaceClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainInterfaceClass->addToolBar(Qt::TopToolBarArea, mainToolBar);

        menuBar->addAction(menuemployees->menuAction());
        menuemployees->addAction(actionAddEmployees);
        menuemployees->addAction(actionViewingEmployee);

        retranslateUi(MainInterfaceClass);

        QMetaObject::connectSlotsByName(MainInterfaceClass);
    } // setupUi

    void retranslateUi(QMainWindow *MainInterfaceClass)
    {
        MainInterfaceClass->setWindowTitle(QCoreApplication::translate("MainInterfaceClass", "MainInterface", nullptr));
        actionAddEmployees->setText(QCoreApplication::translate("MainInterfaceClass", "\346\267\273\345\212\240\345\221\230\345\267\245", nullptr));
        actionViewingEmployee->setText(QCoreApplication::translate("MainInterfaceClass", "\345\221\230\345\267\245\346\237\245\347\234\213", nullptr));
        menuemployees->setTitle(QCoreApplication::translate("MainInterfaceClass", "\345\221\230\345\267\245\347\256\241\347\220\206", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainInterfaceClass: public Ui_MainInterfaceClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAININTERFACE_H
