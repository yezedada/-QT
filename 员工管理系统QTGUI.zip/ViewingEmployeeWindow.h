﻿#pragma once

#include <QWidget>
#include "ui_ViewingEmployeeWindow.h"
#include "AddAndModifyEmployeesWindow.h"
#include "Worker.h"
#include "Boss.h"
#include "Manager.h"
#include "Employee.h"
#include <qfiledialog.h>

QT_BEGIN_NAMESPACE
namespace Ui { class ViewingEmployeeWindowClass; };
QT_END_NAMESPACE


class ViewingEmployeeWindow : public QWidget
{
	Q_OBJECT

public:
	ViewingEmployeeWindow(QWidget *parent = nullptr);
	~ViewingEmployeeWindow();

	//表格初始化
	void TableInit(int EmployeeNumber,Worker** worker);

	//修改属性窗口
	AddAndModifyEmployeesWindow* modWindow = NULL;

	//删除数据所在位置
	int getDeleteEmployeeIndex();

signals:
	void signalsDeleteInformation();

private:
	Ui::ViewingEmployeeWindowClass *ui;
	
	//修改属性窗口
	void ModifyWindow();
	//获取员工的原本信息
	void ReadEmployeeInformation();
	//删除员工信息
	void DeleteEmployeeInformation();

	//按搜索条件查询显示数据
	void ConditionsQuery();

	//修改信息存取
	Worker* modWorker = NULL;
	//修改信息的位置
	int modWokerIndex = 0;
	//当前已有职工数读取
	int EmployeeNumber = 0;
	//记录已经存取的职工数
	Worker** EmployeeInformation = NULL;
};
