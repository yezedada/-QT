﻿#pragma once
#include "Worker.h"
class Manager :  public Worker
{
public:
	//显示信息
	virtual void ShowInfomation();
	//获得岗位名称
	virtual string getDeptName();

	Manager(string id, string name, string dId, string gender, int wage, string marital, short year, short month, short day);
};

