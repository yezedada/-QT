﻿#include "workerManager.h"
using namespace std;

WorkerManager::WorkerManager()
{
	//初始化数据
	this->Read();
}

WorkerManager::~WorkerManager()
{
	if (this->m_EmpArray != NULL)
	{
		//释放数组里的元素内存
		for (int i = 0; i < this->m_EmpNum; i++)
		{
			if (this->m_EmpArray[i] != NULL)
			{
				delete this->m_EmpArray[i];
			}
		}
		//释放数组内存
		this->m_EmpNum = 0;
		delete[] this->m_EmpArray;
		this->m_EmpArray = NULL;
		this->m_FileIsEmpty = true;
	}
}
//检测职工编号是否重复
bool WorkerManager::TestEmpNumRepetition(string id)
{
	for (int i = 0; i < m_EmpNum; i++)
	{
		if (this->m_EmpArray[i]->m_ID == id)
		{
			return true;
		}
	}
	return false;
}
//检测正在输入的职工编号是否重复 true重复 false不重复
bool WorkerManager::TestActiveEmpNumRepetition(string id, string* id_temp, int id_num)
{
	for (int i = 0; i < id_num; i++)
	{
		if (id_temp[i] == id)
		{
			return true;
		}
	}
	return false;
}

//展示菜单
void WorkerManager::ShowMenu()
{
	cout << "**********************************" << endl;
	cout << "*****欢迎使用职工管理系统*********" << endl;
	cout << "********0.退出管理程序  **********" << endl;
	cout << "******  1.增加职工信息  **********" << endl;
	cout << "******  2.显示职工信息  **********" << endl;
	cout << "******  3.删除离职职工  **********" << endl;
	cout << "******  4.修改职工信息  **********" << endl;
	cout << "******  5.查找职工信息  **********" << endl;
	cout << "******  6.按照编号排序  **********" << endl;
	cout << "******  7.清空所有文档  **********" << endl;
	cout << "**********************************" << endl;
	cout << endl;
}
//退出功能
void WorkerManager::ExitSystem()
{
	cout << "欢迎下次使用" << endl;
	system("pause");
	exit(0);
}
//保存文件
void WorkerManager::Save()
{
	ofstream ofs;
	ofs.open(FILENAME, ios::out);

	for (int i = 0; i < this->m_EmpNum; i++)
	{
		ofs << this->m_EmpArray[i]->m_ID << "\t"
			<< this->m_EmpArray[i]->m_Name << "\t"
			<< this->m_EmpArray[i]->m_DeptId << endl;
	}
	ofs.close();
}
//读取文件
void WorkerManager::Read()
{
	ifstream ifs;
	ifs.open(FILENAME, ios::in);

	//文件不存在情况
	if (!ifs.is_open())
	{
		//cout << "文件不存在" << endl;
		//文件为空
		this->m_FileIsEmpty = true;
		//初始化人数
		this->m_EmpNum = 0;
		//初始化数组指针
		this->m_EmpArray = NULL;
		ifs.close();
		return;
	}
	//文件存在，但是没有记录
	char ch;
	ifs >> ch;
	if (ifs.eof()) //判断结尾标志是否存在
	{
		//cout << "文件为空!" << endl;
		//文件为空
		this->m_FileIsEmpty = true;
		//初始化人数
		this->m_EmpNum = 0;
		//初始化数组指针
		this->m_EmpArray = NULL;
		ifs.close();
		return;
	}
	 //文件存在，并且有记录
	int num = this->getEmpNum();
	//cout << "职工人数:" << num << endl;
	//更新职工人数
	this->m_EmpNum = num;
	//初始化职工
	this->initEmp();

}

//记录职工人数
int WorkerManager::getEmpNum()
{
	ifstream ifs;
	ifs.open(FILENAME, ios::in);

	string id, name, dId;

	int num = 0;

	while (ifs >> id && ifs >> name && ifs >> dId)
	{
		num++; //记录人数
	}
	ifs.close();
	return num;
}

//初始化员工
void WorkerManager::initEmp()
{
	ifstream ifs;
	ifs.open(FILENAME, ios::in);

	string id, name;
	char dId;
	this->m_EmpArray = new Worker * [this->m_EmpNum];

	int num = 0;
	while (ifs >> id && ifs >> name && ifs >> dId)
	{
		Worker* worker = NULL;
		switch (dId)
		{
		case '1':
			worker = new Employee(id, name, dId);
			break;
		case '2':
			worker = new Manager(id, name, dId);
			break;
		case '3':
			worker = new Boss(id, name, dId);
			break;
		default:
			cout << "数据文件中第" << num + 1 << "条第三列数据错误" << endl;
			cout << "请修复后运行" << endl;
			system("pause");
			exit(0);
			break;
		}
		
		this->m_EmpArray[num] = worker;
		
		num++;
	}
	ifs.close();
}

//增加职工
void WorkerManager::AddEmp()
{
	//保存用户的输入数量
	int addNum = 0;

	cout << "请输入增加职工的数量:" ;
	cin >> addNum;

	if (addNum > 0)
	{
		//计算添加的新空间人数
		int newSize = this->m_EmpNum + addNum;

		//开辟新空间
		Worker** newSpace = new Worker * [newSize];

		//存储已添加的编号，防止重复
		id_temp = new string[addNum];
		
		//将原来空间下的数据拷贝到新空间
		if (this->m_EmpArray != NULL)
		{
			for (int i = 0; i < this->m_EmpNum; i++)
			{
				newSpace[i] = this->m_EmpArray[i];
			}
		}
		//添加新数据
		for (int i = 0; i < addNum; i++)
		{
			string id, name;
			char dSelect ;//部门选择

			cout << "请输入第" << i + 1 << "个新职工的编号:";
			cin >> id;
			//判断输入的编号与已有的编号是否相同
			while (this->TestEmpNumRepetition(id) || this->TestActiveEmpNumRepetition(id, id_temp, NewAddData))
			{

				cout << "输入的员工编号与其余员工重复,请重新输入:";
				cin >> id;
			}
			//输入个数+1
			NewAddData++;
			id_temp[i] = id;

			cout << "请输入第" << i + 1 << "个新职工的姓名:";
			cin >> name;
			cout << "请选择该职工的岗位:" << endl;
			cout << "1.普通职工" << endl;
			cout << "2.项目经理" << endl;
			cout << "3.公司老板" << endl;

			Worker* worker = NULL;
			bool workerAddSucceed = false;
			while (workerAddSucceed != true)
			{
				cin >> dSelect;
				switch (dSelect)
				{
				case '1':
					worker = new Employee(id, name, '1');
					workerAddSucceed = true;
					break;
				case '2':
					worker = new Manager(id, name, '2');
					workerAddSucceed = true;
					break;
				case '3':
					worker = new Boss(id, name, '3');
					workerAddSucceed = true;
					break;
				default: cout << "选择有误！重新输入！" << endl;
					break;
				}
			}			
			//将职工指针存入数组中
			newSpace[this->m_EmpNum + i] = worker;
		}
		//清空输入了的个数
		NewAddData = 0;

		//释放存放编号
		delete[] this->id_temp;
		//释放原有的空间
		delete[] this->m_EmpArray;

		//更改新空间的指向
		this->m_EmpArray = newSpace;

		//更新新的职工人数
		this->m_EmpNum = newSize;

		//成功添加提示
		cout << "成功添加了" << addNum << "名新员工" << endl;
		this->Save();
	}
	else
	{
		cout << "输入的数据有误:" << endl;
	}
}

//显示职工信息
void WorkerManager::ShowEmpInformation()
{
	if (this->JudgeEmpNum())
	{
		for (int i = 0; i < this->m_EmpNum; i++)
		{
			this->m_EmpArray[i]->ShowInfomation();
		}
	}
}

//检查职工是否存在 不存在-1	存在ID号
int WorkerManager::IsExit(string id)
{
	int index = -1;
	for (int i = 0; i < this->m_EmpNum; i++)
	{
		if (this->m_EmpArray[i]->m_ID == id)
		{
			index = i;
			break;
		}
	}
	if (index == -1)
	{
		cout << "查无此人" << endl;
	}
	return index;
}

//判断有无职工  true有 false无
bool WorkerManager::JudgeEmpNum()
{
	if (this->m_EmpNum != 0)
	{
		return true;
	}
	else
	{
		cout << "当前没有任何职工" << endl;
		return false;
	}
}

//删除离职职工
void WorkerManager::DeleteEmp()
{
	if (this->JudgeEmpNum())
	{
		string id;
		char deleteValue = 'n';
		int empIndex = -1;
		Worker* temp = NULL;
		cout << "请输入你要删除的职工编号:";
		cin >> id;

		empIndex = this->IsExit(id);

		//显示该职工的信息
		if (empIndex != -1)
		{
			this->m_EmpArray[empIndex]->ShowInfomation();
			cout << "是否真的删除该员工?(Y/N)" << endl;
			cin >> deleteValue;
			switch (deleteValue)
			{
			case 'Y':
			case 'y':
			case '1':
				temp = this->m_EmpArray[empIndex];
				for (short j = empIndex; j < this->m_EmpNum - 1; j++)
				{
					this->m_EmpArray[j] = this->m_EmpArray[j + 1];
				}
				delete temp;
				this->m_EmpNum--;
				this->Save();
				cout << "删除成功!!!" << endl;
				break;
			case 'N':
			case 'n':
			case '2':
				cout << "取消删除!!!" << endl;
				break;
			default:
				break;
			}
		}
		
	}
}

//修改职工信息
void WorkerManager::ModEmp()
{
	if (this->JudgeEmpNum())
	{
		string id;
		int empIndex = -1;
		char modInfomationOption = '0';//修改信息选项
		bool workerAddSucceed = false;//部门选择是否正确
		cout << "请输入你要修改的职工编号:";
		cin >> id;
		empIndex = this->IsExit(id);
		if (empIndex != -1)
		{
			this->m_EmpArray[empIndex]->ShowInfomation();
			cout << "请问你要修改该员工的什么信息?" << endl;
			cout << "1.工号\t2.姓名\t3.职工岗位\t请输入:";
			cin >> modInfomationOption;
			while (workerAddSucceed != true)
			{
				switch (modInfomationOption)
				{
				case '1':
					cout << "请输入新的工号:";
					cin >> id;
					while (this->TestEmpNumRepetition(id))
					{
						cout << "输入的员工编号与其余员工重复,请重新输入:";
						cin >> id;
					}
					this->m_EmpArray[empIndex]->m_ID = id;
					workerAddSucceed = true;
						break;
				case '2':
					cout << "请输入新的姓名:";
					cin >> this->m_EmpArray[empIndex]->m_Name;
					workerAddSucceed = true;
					break;
				case '3':
					this->DeptIDSelete(empIndex);
					workerAddSucceed = true;
					break;
				default:
					cout << "选择有误！重新输入！" << endl;
					break;
				}
			}
			cout << "修改成功" << endl;
			this->Save();
		}
	}
}
//公司岗位选择
void WorkerManager::DeptIDSelete(int empIndex)
{
	char dSelect = '0';
	cout << "1.普通职工" << endl;
	cout << "2.项目经理" << endl;
	cout << "3.公司老板" << endl;
	cout << "请输入新的岗位:" ;
	Worker* worker = NULL;
	bool workerAddSucceed = false;
	while (workerAddSucceed != true)
	{
		cin >> dSelect;
		switch (dSelect)
		{
		case '1':
			worker = new Employee(this->m_EmpArray[empIndex]->m_ID, this->m_EmpArray[empIndex]->m_Name, '1');
			workerAddSucceed = true;
			break;
		case '2':
			worker = new Manager(this->m_EmpArray[empIndex]->m_ID, this->m_EmpArray[empIndex]->m_Name, '2');
			workerAddSucceed = true;
			break;
		case '3':
			worker = new Boss(this->m_EmpArray[empIndex]->m_ID, this->m_EmpArray[empIndex]->m_Name, '3');
			workerAddSucceed = true;
			break;
		default: cout << "选择有误！重新输入！" << endl;
			break;
		}
	}
	delete this->m_EmpArray[empIndex];
	this->m_EmpArray[empIndex] = worker;
}
//查找职工
void WorkerManager::FindEmp()
{
	if (this->JudgeEmpNum())
	{
		char select = '0';
		string id, name;
		int index;
		bool findName = false;
		while (true)
		{
			cout << "1.按照编号查找\t2.按照姓名查找\t0.取消查找\n请选择:";
			cin >> select;
			switch (select)
			{
			case '0': 
				return;
				break;
			case '1':
				cout << "请输入要查找的编号:";
				cin >> id;
				index = this->IsExit(id);
				if (index != -1)
				{
					this->m_EmpArray[index]->ShowInfomation();
				}
				system("pause");
				system("cls");
				break;
			case '2':
				cout << "请输入要查找的姓名:";
				cin >> name;
				for (int i = 0; i < this->m_EmpNum; i++)
				{
					if (this->m_EmpArray[i]->m_Name == name)
					{
						this->m_EmpArray[i]->ShowInfomation();
						findName = true;
					}
				}
				if (findName != true)
				{
					cout << "查无此人" << endl;
				}
				system("pause");
				system("cls");
				break;
			default:
				cout << "输入错误，请重新输入" << endl;
				system("pause");
				system("cls");
				break;
			}
		}
	}
}

//按照职工编号排序
void WorkerManager::EmpIdRank()
{
	if (this->JudgeEmpNum())
	{
		Worker* worker = NULL;
		int id1, id2;
		char sortordTemp = '0';
		for (int i = 0; i < this->m_EmpNum - 1; i++)
		{
			id1 = atoi(this->m_EmpArray[i]->m_ID.c_str());
			id2 = atoi(this->m_EmpArray[i+1]->m_ID.c_str());
			cout << "请输入你的排序方式   1.升序 0.降序\t请输入:";
			cin >> sortordTemp;
			if (sortordTemp == '1')
			{
				if (id1 > id2)
				{
					worker = this->m_EmpArray[i];
					this->m_EmpArray[i] = this->m_EmpArray[i + 1];
					this->m_EmpArray[i + 1] = worker;
				}
			}
			else
			{
				if (id1 < id2)
				{
					worker = this->m_EmpArray[i];
					this->m_EmpArray[i] = this->m_EmpArray[i + 1];
					this->m_EmpArray[i + 1] = worker;
				}
			}
			
		}
		this->Save();
		cout << "排序成功" << endl;
	}
	
}

//清空文件
void WorkerManager::CleanFile()
{
	cout << "确实清空?\t1.确认\t2.返回\t请输入:" ;
	char select = '0';
	cin >> select;
	if (select == '1')
	{
		//文件打开模式  ios::trunc 如果存在删除文件并重新创建
		ofstream ofs(FILENAME, ios::trunc);
		ofs.close();

		if (this->m_EmpArray != NULL)
		{
			//释放数组里的元素内存
			for (int i = 0; i < this->m_EmpNum; i++)
			{
				if (this->m_EmpArray[i] != NULL)
				{
					delete this->m_EmpArray[i];
				}
			}
			//释放数组内存
			this->m_EmpNum = 0;
			delete[] this->m_EmpArray;
			this->m_EmpArray = NULL;
			this->m_FileIsEmpty = true;
		}
		cout << "清空成功!" << endl;
	}
	else
	{
		return;
	}
}