﻿#include "AddAndModifyEmployeesWindow.h"
#include "Boss.h"
#include "Manager.h"
#include "Employee.h"
#include <qdebug.h>
#include <qmessagebox.h>

AddAndModifyEmployeesWindow::AddAndModifyEmployeesWindow(QWidget *parent)
	: QWidget(parent)
	, ui(new Ui::AddAndModifyEmployeesWindowClass())
{
	ui->setupUi(this);
	this->setWindowTitle("添加员工");
    this->modWorkerIndex = 0;
    this->ui->GetDate->setCalendarPopup(true);

    connect(this->ui->AddAndModBtn, &QPushButton::clicked, this, [=]()
        {
            if (this->IsAddModBtn != true)
            {
                qDebug() << "添加按钮信息";
                qDebug() << "添加信息";
                this->MessageBoxError = false;
                this->AddEmployees();
                //信息输入错误就退出，不用更新数据
                if (this->MessageBoxError != false)
                {
                    return;
                }
                qDebug() << "更新信息";
                emit this->signalsAddInformation();
                QMessageBox::information(this, "消息提示", "添加成功");
            }
            else
            {
                qDebug() << "修改按钮信息";
                this->MessageBoxError = false;
                //获取修改后的信息
                this->ModifyEmployeeInformation();
                //信息输入错误就退出，不用更新数据
                if (this->MessageBoxError != false)
                {
                    return;
                }
                qDebug() << "更新信息";
                emit this->signalsModInformation();
                QMessageBox::information(this, "消息提示", "修改成功");
            }      
        });



    //监听添加窗口的重置参数
    connect(this->ui->ResetBtn, &QPushButton::clicked, this, [=]()
        {
            this->ui->GetEmployeesNumber->clear();
            this->ui->GetEmployeesName->clear();
            this->ui->GetEmployeesPosition->setCurrentIndex(0);
            this->ui->GetEmployeesGender->setCurrentIndex(0);
            this->ui->GetEmployeesMarital->setCurrentIndex(0);
            this->ui->GetEmployeesWage->clear();
            this->ui->GetDate->setDate(QDate(2000, 1, 1));
        });
}


AddAndModifyEmployeesWindow::~AddAndModifyEmployeesWindow()
{
	delete ui;
}

//添加新员工
void AddAndModifyEmployeesWindow::AddEmployees()
{
    QString number, name, position, gender, wage, marital;
    QDate date;
    
    number = this->ui->GetEmployeesNumber->text();
    name = this->ui->GetEmployeesName->text();
    //防止空的员工属性
    if (number == NULL || name == NULL)
    {
        QMessageBox::warning(this, "错误提示框", "不能有空值！");
        this->MessageBoxError = true;
        return;
    }
    //防止重复的员工属性
    for (int i = 0; i < this->m_EmployeeNum; i++)
    {
        if (QString::fromStdString(this->m_EmployeeInfomation[i]->m_ID) == number)
        {
            QMessageBox::warning(this, "错误提示框", "员工编号重复！");
            this->MessageBoxError = true;
            return;
        }
    }

    //创建临时员工信息
    Worker** temp = new Worker * [this->m_EmployeeNum + sizeof(Worker)];
    //创建新员工对象
    Worker* newSpace = NULL;
    //将原来空间下的数据拷贝到新空间
    if (this->m_EmployeeInfomation != NULL)
    {
        for (int i = 0; i < this->m_EmployeeNum; i++)
        {
            temp[i] = this->m_EmployeeInfomation[i];
        }
    }

    position = this->ui->GetEmployeesPosition->currentText();
    gender = this->ui->GetEmployeesGender->currentText();
    wage = this->ui->GetEmployeesWage->text();
    marital = this->ui->GetEmployeesMarital->currentText();
    date = this->ui->GetDate->date();
    

    if (position.compare(QString::fromLocal8Bit("普通职工")) == 0)
    {
        //创建员工对象
        newSpace = new Employee(number.toStdString(), name.toStdString(), position.toStdString()
                    , gender.toStdString(), wage.toInt(), marital.toStdString(), date.year(), date.month(), date.day());
    }
    else if (position.compare(QString::fromLocal8Bit("经理")) == 0)
    {
        //创建员经理对象
        newSpace = new Manager(number.toStdString(), name.toStdString(), position.toStdString()
            , gender.toStdString(), wage.toInt(), marital.toStdString(), date.year(), date.month(), date.day());
    }
    else
    {
        //创建员老板对象
        newSpace = new Boss(number.toStdString(), name.toStdString(), position.toStdString()
            , gender.toStdString(), wage.toInt(), marital.toStdString(), date.year(), date.month(), date.day());
    }

    temp[this->m_EmployeeNum] = newSpace;

    //去掉原来的指向
    delete[] this->m_EmployeeInfomation;
    //更新指向
    this->m_EmployeeInfomation = temp;

    //测试一下是否输入正确   测试用代码
    number = QString::fromStdString(this->m_EmployeeInfomation[this->m_EmployeeNum]->m_ID);
    name = QString::fromStdString(this->m_EmployeeInfomation[this->m_EmployeeNum]->m_Name);
    position = QString::fromStdString(this->m_EmployeeInfomation[this->m_EmployeeNum]->m_DeptId);
    gender = QString::fromStdString(this->m_EmployeeInfomation[this->m_EmployeeNum]->m_Gender);
    marital = QString::fromStdString(this->m_EmployeeInfomation[this->m_EmployeeNum]->m_Marital);
    wage = QString::number(this->m_EmployeeInfomation[this->m_EmployeeNum]->m_Wage);
    qDebug() << number<< " " << name << " " << position << " " << gender << " " << marital << " " << wage;

    //更新员工人数
    this->m_EmployeeNum++;
}

//修改员工信息
void AddAndModifyEmployeesWindow::ModifyEmployeeInformation()
{
    QString id, name, deptId, gender, wage, marital;
    QDate date;
    //获取修改后的员工信息
    id = this->ui->GetEmployeesNumber->text();
    name = this->ui->GetEmployeesName->text();
    //防止空的员工属性
    if (id == NULL || name == NULL)
    {
        QMessageBox::warning(this, "错误提示框", "不能有空值！");
        this->MessageBoxError = true;
        return;
    }
    //防止重复的员工属性
    for (int i = 0; i < this->m_EmployeeNum; i++)
    {
        //防止员工与其余员工ID重复，可以与自己之前的一样
        if (QString::fromStdString(this->m_EmployeeInfomation[i]->m_ID) == id && QString::fromStdString(this->m_EmployeeInfomation[this->modWorkerIndex]->m_ID) != id)
        {
            QMessageBox::warning(this, "错误提示框", "员工编号重复！");
            this->MessageBoxError = true;
            return;
        }
    }

    deptId = this->ui->GetEmployeesPosition->currentText();
    gender = this->ui->GetEmployeesGender->currentText();
    wage = this->ui->GetEmployeesWage->text();
    marital = this->ui->GetEmployeesMarital->currentText();
    date = this->ui->GetDate->date();

    if (deptId.compare(QString::fromLocal8Bit("普通职工")) == 0)
    {
        //创建员工对象
        this->modWorker = new Employee(id.toStdString(), name.toStdString(), deptId.toStdString()
            , gender.toStdString(), wage.toInt(), marital.toStdString(), date.year(), date.month(), date.day());
    }
    else if (deptId.compare(QString::fromLocal8Bit("经理")) == 0)
    {
        //创建员经理对象
        this->modWorker = new Manager(id.toStdString(), name.toStdString(), deptId.toStdString()
            , gender.toStdString(), wage.toInt(), marital.toStdString(), date.year(), date.month(), date.day());
    }
    else
    {
        //创建员老板对象
        this->modWorker = new Boss(id.toStdString(), name.toStdString(), deptId.toStdString()
            , gender.toStdString(), wage.toInt(), marital.toStdString(), date.year(), date.month(), date.day());
    }
}

//设置员工修改的数据位置
void AddAndModifyEmployeesWindow::setModWorkerIndex(int Index)
{
    this->modWorkerIndex = Index;
}


//获得修改员工的信息
Worker* AddAndModifyEmployeesWindow::getModifyEmployeeInfomation()
{
    return modWorker;
}
//获得修改员工的数据位置
int AddAndModifyEmployeesWindow::getModifyEmployeeIndex()
{
    return modWorkerIndex;
}

//设置修改员工属性
void AddAndModifyEmployeesWindow::setModifyEmployeeInfomation(Worker** EmployeeInfomation)
{
    this->m_EmployeeInfomation = EmployeeInfomation;
}
//设置修改员工人数
void AddAndModifyEmployeesWindow::setModifyEmployeeNumber(int EmployeeNum)
{
    this->m_EmployeeNum = EmployeeNum;
}

//获得员工对象信息
Worker** AddAndModifyEmployeesWindow::getEmployeeInfomation()
{
    return m_EmployeeInfomation;
}

//获得员工数量
int AddAndModifyEmployeesWindow::getEmployeeNumber()
{
    qDebug() << this->m_EmployeeNum;
    return this->m_EmployeeNum;
}

//设置员工数量
void AddAndModifyEmployeesWindow::setEmployeeNumber(int number)
{
    this->m_EmployeeNum = number;
}

//设置员工对象信息
void AddAndModifyEmployeesWindow::setEmployeeInfomation(Worker** EmployeeInfomation)
{
    this->m_EmployeeInfomation = EmployeeInfomation;
}