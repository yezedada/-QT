﻿#include "Manager.h"
//显示信息
void Manager::ShowInfomation()
{

}
//获得岗位名称
string Manager::getDeptName()
{
	return this->m_DeptId;
}

Manager::Manager(string id, string name, string dId, string gender, int wage, string marital, short year, short month, short day)
{
	this->m_ID = id;
	this->m_Name = name;
	this->m_DeptId = dId;
	this->m_Gender = gender;
	this->m_Wage = wage;
	this->m_Marital = marital;
	this->day = day;
	this->month = month;
	this->year = year;
}