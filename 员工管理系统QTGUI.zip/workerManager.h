﻿#pragma once
#include <iostream>
#include "Worker.h"
#include "Employee.h"
#include "Boss.h"
#include "Manager.h"
#include <fstream>

#define FILENAME "职工信息.txt"

using namespace std;
class WorkerManager
{
public:
	//记录文件中的人数个数
	int m_EmpNum;

	//员工数组的指针
	Worker** m_EmpArray;

	//展示菜单
	void ShowMenu();
	//退出功能
	void ExitSystem();
	//增加职工
	void AddEmp();
	//显示职工信息
	void ShowEmpInformation();
	//删除离职职工
	void DeleteEmp();
	//修改职工信息
	void ModEmp();
	//查找职工
	void FindEmp();
	//按照职工编号排序 
	void EmpIdRank();
	//清空文件
	void CleanFile();

	//记录职工人数
	int getEmpNum();

	WorkerManager();
	~WorkerManager();

private:
	//标志文件是否为空
	bool m_FileIsEmpty = false;
	//保存文件
	void Save();
	//读取文件
	void Read();
	//初始化员工
	void initEmp();

	//检查职工是否存在 存在返回数组位置 不存在返回-1
	int IsExit(string id);

	//判断有无职工  true有 false无
	bool JudgeEmpNum();

	//公司岗位选择
	void DeptIDSelete(int empIndex);

	//检测职工编号是否重复 true重复 false不重复
	bool TestEmpNumRepetition(string id);

	//检测正在输入的职工编号是否重复 true重复 false不重复
	bool TestActiveEmpNumRepetition(string id, string * id_temp, int id_num);

	//记录新加载的数据
	int NewAddData = 0;

	//存储已添加的编号，防止重复
	string* id_temp = NULL;
};

