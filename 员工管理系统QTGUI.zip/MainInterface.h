﻿#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_MainInterface.h"
#include "Worker.h"
#include "ViewingEmployeeWindow.h"
#include "AddAndModifyEmployeesWindow.h"
#include <qevent.h>

QT_BEGIN_NAMESPACE
namespace Ui { class MainInterfaceClass; };
QT_END_NAMESPACE

#define FILEPATH "员工信息.txt"

class MainInterface : public QMainWindow
{
    Q_OBJECT

public:
    MainInterface(QWidget *parent = nullptr);
    ~MainInterface();

    //设置员工对象
    Worker** worker = NULL;


    //添加员工信息
    void AddInformation();
    //显示员工信息
    void ShowEmployees();

    //修改员工信息
    void ModifyInformation();
    //删除员工信息
    void DeleteInformation();

private:
    Ui::MainInterfaceClass *ui;

    //员工添加窗口
    AddAndModifyEmployeesWindow* addWindow = NULL;
    //员工查看窗口
    ViewingEmployeeWindow* viewWindow = NULL;

    //设置员工数量
    int m_EmployeeNum = 0;

    //修改员工对象
    Worker* modWorker = NULL;
    //修改员工位置
    int modWorkerIndex;

    //在文件中读取数据
    void ReadFileDate();
    //把数据写入文件
    void WriteFileDate();
    //文件数据个数判断
    int FileDataNum();

    //重写退出事件
    void closeEvent(QCloseEvent* event);
};
