﻿#include "ViewingEmployeeWindow.h"
#include <qstringlist.h>
#include "AddAndModifyEmployeesWindow.h"
#include <qdebug.h>
#include <qmessagebox.h>

ViewingEmployeeWindow::ViewingEmployeeWindow(QWidget *parent)
	: QWidget(parent)
	, ui(new Ui::ViewingEmployeeWindowClass())
{
	ui->setupUi(this);
	this->setWindowTitle("员工信息");
	this->resize(1000, 600);

	this->modWindow = new AddAndModifyEmployeesWindow;

	//监听修改窗口
	connect(ui->ModifyBtn, &QPushButton::clicked, this, [=]()
		{
			//启动修改窗口
			this->ModifyWindow();
			//读取员工原本信息放到修改窗口中
			this->ReadEmployeeInformation();
		});
	//监听删除按钮
	connect(ui->DeleteBtn, &QPushButton::clicked, this, [=]()
		{
			int choose;
			choose = QMessageBox::question(this, tr("删除员工信息"),
				QString(tr("确认删除该员工信息?")),
				QMessageBox::Yes | QMessageBox::No);
			if (choose == QMessageBox::No)
			{
				return;
			}
			else if (choose == QMessageBox::Yes)
			{
				this->DeleteEmployeeInformation();
				//发送删除数据信号
				emit this->signalsDeleteInformation();
			}		
		});
	//监听搜索按钮
	connect(ui->SearchBtn, &QPushButton::clicked, this, [=]()
		{
			this->ConditionsQuery();
		});
}

ViewingEmployeeWindow::~ViewingEmployeeWindow()
{
	delete ui;
}

//表格初始化 (职工数量, 职工存储对象)
void ViewingEmployeeWindow::TableInit(int EmployeeNumber, Worker** worker)
{
	//设置列数
	ui->tableWidget->setColumnCount(7);
	QStringList	list;
	list << "职工编号" << "姓名" << "岗位"<< "性别" << "工资" << "出生日期"<< "婚姻状况";
	ui->tableWidget->setHorizontalHeaderLabels(list);

	//设置列宽
	ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	//设置表格不可修改
	ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

	//表格行数初始化 dataNumber
	ui->tableWidget->setRowCount(EmployeeNumber);

	for (int i = 0; i < EmployeeNumber; i++)
	{
		Worker* temp = worker[i];
		QTableWidgetItem* item0 = new QTableWidgetItem(QString::fromStdString(temp->m_ID));
		QTableWidgetItem* item1 = new QTableWidgetItem(QString::fromStdString(temp->m_Name));
		QTableWidgetItem* item2 = new QTableWidgetItem(QString::fromStdString(temp->m_DeptId));
		QTableWidgetItem* item3 = new QTableWidgetItem(QString::fromStdString(temp->m_Gender));
		QTableWidgetItem* item4 = new QTableWidgetItem(QString::number(temp->m_Wage));
		QTableWidgetItem* item5 = new QTableWidgetItem(QDate(temp->year, temp->month, temp->day).toString("yyyy-MM-dd"));
		QTableWidgetItem* item6 = new QTableWidgetItem(QString::fromStdString(temp->m_Marital));

		ui->tableWidget->setItem(i, 0, item0);
		ui->tableWidget->setItem(i, 1, item1);
		ui->tableWidget->setItem(i, 2, item2);
		ui->tableWidget->setItem(i, 3, item3);
		ui->tableWidget->setItem(i, 4, item4);
		ui->tableWidget->setItem(i, 5, item5);
		ui->tableWidget->setItem(i, 6, item6);
		this->ui->tableWidget->setRowHidden(i, false);
	}

	//将职工数记录到该框架
	this->EmployeeNumber = EmployeeNumber;
	//将职工信息记录到该框架
	this->EmployeeInformation = worker;
}

//修改属性窗口
void ViewingEmployeeWindow::ModifyWindow()
{
	this->modWindow->setWindowTitle("修改员工");
	this->modWindow->show();
	this->modWindow->ui->AddAndModBtn->setText("修改");
	//设置修改按钮标志
	this->modWindow->IsAddModBtn = true;

	this->modWindow->setModifyEmployeeNumber(this->EmployeeNumber);
	this->modWindow->setModifyEmployeeInfomation(this->EmployeeInformation);
}

//读取员工原本信息放到修改窗口中
void ViewingEmployeeWindow::ReadEmployeeInformation()
{
	//如果没有存放员工，直接退出掉读取数据
	if (this->EmployeeNumber == 0)
	{
		return;
	}

	QString id, name, deptId, gender, wage, date, marital;
	//获取选中的行数
	this->modWokerIndex = this->ui->tableWidget->currentRow();
	//读取选中行的数据
	id = this->ui->tableWidget->item(this->modWokerIndex, 0)->text();
	name = this->ui->tableWidget->item(this->modWokerIndex, 1)->text();
	deptId = this->ui->tableWidget->item(this->modWokerIndex, 2)->text();
	gender = this->ui->tableWidget->item(this->modWokerIndex, 3)->text();
	wage = this->ui->tableWidget->item(this->modWokerIndex, 4)->text();
	date = this->ui->tableWidget->item(this->modWokerIndex, 5)->text();
	marital = this->ui->tableWidget->item(this->modWokerIndex, 6)->text();
	//显示选中的员工信息
	this->modWindow->ui->GetEmployeesNumber->setText(id);
	this->modWindow->ui->GetEmployeesName->setText(name);
	this->modWindow->ui->GetEmployeesPosition->setCurrentText(deptId);
	this->modWindow->ui->GetEmployeesGender->setCurrentText(gender);
	this->modWindow->ui->GetEmployeesWage->setText(wage);
	this->modWindow->ui->GetEmployeesMarital->setCurrentText(marital);
	this->modWindow->ui->GetDate->setDate(QDate::fromString(date));

	//发送读取修改数据的位置
	this->modWindow->setModWorkerIndex(this->modWokerIndex);
}

//删除员工信息
void ViewingEmployeeWindow::DeleteEmployeeInformation()
{
	//获取选中的行数
	this->modWokerIndex = this->ui->tableWidget->currentRow();

	//删除该行数据
	this->ui->tableWidget->removeRow(this->modWokerIndex);
}

//删除数据所在位置
int ViewingEmployeeWindow::getDeleteEmployeeIndex()
{
	return this->modWokerIndex;
}

//按搜索条件查询显示数据
void ViewingEmployeeWindow::ConditionsQuery()
{
	QString number, name;
	//获得搜索框中的内容
	number = this->ui->GetEmpNumber->text();
	name = this->ui->GetEmpName->text();

	
	for (int i = 0; i < this->EmployeeNumber; i++)
	{
		//隐藏表格
		this->ui->tableWidget->setRowHidden(i, true);
		//职工编号与姓名都搜索
		if (number != NULL && name != NULL)
		{
			qDebug() << "都搜索";
			if (QString::fromStdString(this->EmployeeInformation[i]->m_ID) == number && QString::fromStdString(this->EmployeeInformation[i]->m_Name) == name)
			{
				this->ui->tableWidget->setRowHidden(i, false);
			}
		}
		//判断搜索职工编号
		else if (QString::fromStdString(this->EmployeeInformation[i]->m_ID) == number && number != NULL)
		{
			qDebug() << "搜索编号";
			this->ui->tableWidget->setRowHidden(i, false);
		}
		//判断搜索姓名
		else if (QString::fromStdString(this->EmployeeInformation[i]->m_Name) == name && name != NULL)
		{
			qDebug() << "搜索姓名";
			this->ui->tableWidget->setRowHidden(i, false);
		}
	}
	//不搜索
	if (number == NULL && name == NULL)
	{
		for (int i = 0; i < this->EmployeeNumber; i++)
		{
			this->ui->tableWidget->setRowHidden(i, false);
		}
	}
}