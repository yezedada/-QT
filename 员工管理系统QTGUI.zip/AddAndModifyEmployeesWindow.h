﻿#pragma once

#include <QWidget>
#include "ui_AddAndModifyEmployeesWindow.h"
#include "Worker.h"
#include <qfiledialog.h>

QT_BEGIN_NAMESPACE
namespace Ui { class AddAndModifyEmployeesWindowClass; };
QT_END_NAMESPACE

class AddAndModifyEmployeesWindow : public QWidget
{
	Q_OBJECT

public:
	Ui::AddAndModifyEmployeesWindowClass* ui;
	AddAndModifyEmployeesWindow(QWidget *parent = nullptr);
	~AddAndModifyEmployeesWindow();
	//bool判断是添加按钮还是修改按钮
	//添加 false 修改 true
	bool IsAddModBtn = false;

	//获得员工对象信息
	Worker** getEmployeeInfomation();
	//设置员工对象信息
	void setEmployeeInfomation(Worker** EmployeeInfomation);
	//获得员工数量
	int getEmployeeNumber();
	//设置员工数量
	void setEmployeeNumber(int number);
	//设置员工修改的数据位置
	void setModWorkerIndex(int Index);

	//获得修改员工的信息
	Worker* getModifyEmployeeInfomation();
	//获得修改员工的数据位置
	int getModifyEmployeeIndex();

	//设置修改员工属性
	void setModifyEmployeeInfomation(Worker** EmployeeInfomation);
	//设置修改员工人数
	void setModifyEmployeeNumber(int EmployeeNum);

signals:
	//发出添加信息信号
	void signalsAddInformation();
	//发出修改信息信号
	void signalsModInformation();

private:
	
	//设置员工数量
	int m_EmployeeNum = 0;
	//设置员工对象
	Worker** m_EmployeeInfomation = NULL;

	//修改员工对象
	Worker* modWorker = NULL;
	//修改员工位置
	int modWorkerIndex;

	//信息是否输入错误判断
	bool MessageBoxError = false;

	//添加员工
	void AddEmployees();
	//修改员工
	void ModifyEmployeeInformation();

};
